package com.dokkanti.app;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import androidx.appcompat.app.AppCompatActivity;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class MainActivity extends AppCompatActivity {
    private WebView web;
    private final androidx.activity.result.ActivityResultLauncher<ScanOptions> barcodeLauncher =
        registerForActivityResult(new ScanContract(), result -> {
            if (result.getContents() != null && web != null) {
                String value = result.getContents().replace("\\", "\\\\").replace("'", "\\'");
                web.evaluateJavascript("window.onBarcodeScanned && window.onBarcodeScanned('" + value + "')", null);
            }
        });
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void scanBarcode() {
                runOnUiThread(() -> {
                    ScanOptions options = new ScanOptions();
                    options.setPrompt("وجّه الكاميرا نحو باركود المنتج");
                    options.setBeepEnabled(false);
                    options.setOrientationLocked(false);
                    options.setDesiredBarcodeFormats(ScanOptions.ONE_D_CODE_TYPES);
                    barcodeLauncher.launch(options);
                });
            }
        }, "Android");
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
}
